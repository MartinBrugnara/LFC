/* Author: Brugnara Martin #157791 */

#ifndef COERCION
#define COERCION

conNodeType * coercion(conNodeType * a, varTypeEnum req);

#endif
