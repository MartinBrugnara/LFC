/* Author: Brugnara Martin #157791 */

#ifndef HELPER
#define HELPER

#include <sys/types.h>

void yyerror(const char *);
void * xmalloc(size_t);

#endif
